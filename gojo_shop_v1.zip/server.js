const express=require("express");
const fs=require("fs"), path=require("path");
const multer=require("multer");
const app=express(), PORT=process.env.PORT||3000;
const ROOT=__dirname, DATA=path.join(ROOT,"data");
const db=()=>JSON.parse(fs.readFileSync(path.join(DATA,"db.json"),"utf8"));
const save=x=>fs.writeFileSync(path.join(DATA,"db.json"),JSON.stringify(x,null,2));
if(!fs.existsSync(path.join(DATA,"db.json"))) save({
  settings:{siteName:"GOJO SHOP",logo:"G",banner:"Tool & File Store",music:"",musicEnabled:true},
  admin:{username:"admin",password:"admin123"},
  users:[],products:[],orders:[],topups:[]
});
app.use(express.json()); app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(ROOT,"public")));
const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,path.join(ROOT,"uploads")),
 filename:(req,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
});
const upload=multer({storage});

app.get("/api/store",(req,res)=>{const d=db();res.json({settings:d.settings,products:d.products});});
app.post("/api/admin/login",(req,res)=>{
 const d=db(); if(req.body.username===d.admin.username&&req.body.password===d.admin.password)
   return res.json({ok:true,token:"admin-demo-token"});
 res.status(401).json({ok:false,message:"Sai tài khoản hoặc mật khẩu"});
});
function admin(req,res,next){if(req.headers.authorization==="Bearer admin-demo-token") return next();res.status(401).json({message:"Unauthorized"});}
app.get("/api/admin/data",admin,(req,res)=>res.json(db()));
app.post("/api/admin/settings",admin,(req,res)=>{
 const d=db(); d.settings={...d.settings,...req.body}; save(d); res.json({ok:true,settings:d.settings});
});
app.post("/api/admin/products",admin,(req,res)=>{
 const d=db(), p={id:Date.now().toString(),name:req.body.name||"Sản phẩm mới",price:Number(req.body.price||0),description:req.body.description||"",file:req.body.file||"",createdAt:new Date().toISOString()};
 d.products.unshift(p);save(d);res.json(p);
});
app.put("/api/admin/products/:id",admin,(req,res)=>{
 const d=db(),p=d.products.find(x=>x.id===req.params.id);if(!p)return res.status(404).end();
 Object.assign(p,{name:req.body.name,price:Number(req.body.price),description:req.body.description,file:req.body.file});save(d);res.json(p);
});
app.delete("/api/admin/products/:id",admin,(req,res)=>{const d=db();d.products=d.products.filter(x=>x.id!==req.params.id);save(d);res.json({ok:true});});
app.post("/api/admin/upload",admin,upload.single("file"),(req,res)=>{
 if(!req.file)return res.status(400).json({message:"Chưa chọn file"});
 res.json({ok:true,file:"/uploads/"+req.file.filename,original:req.file.originalname});
});
app.post("/api/topup",(req,res)=>{
 const d=db(), t={id:Date.now().toString(),user:req.body.user||"guest",method:req.body.method||"card",code:req.body.code||"",serial:req.body.serial||"",amount:Number(req.body.amount||0),status:"pending",createdAt:new Date().toISOString()};
 d.topups.unshift(t);save(d);res.json({ok:true,message:"Đã gửi yêu cầu, chờ Admin duyệt.",topup:t});
});
app.post("/api/admin/topups/:id/status",admin,(req,res)=>{
 const d=db(),t=d.topups.find(x=>x.id===req.params.id);if(!t)return res.status(404).end();
 t.status=req.body.status;save(d);res.json(t);
});
app.get("*",(req,res)=>res.sendFile(path.join(ROOT,"public","index.html")));
app.listen(PORT,()=>console.log(`http://localhost:${PORT}`));