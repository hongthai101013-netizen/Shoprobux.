# GOJO SHOP V1

## Chạy local
1. Cài Node.js 18+.
2. Mở terminal trong thư mục project.
3. Chạy `npm install`.
4. Chạy `npm start`.
5. Mở `http://localhost:3000`.

## Admin demo
Tài khoản: `admin`
Mật khẩu: `admin123`

## Lưu ý
- Đây là bản khung chạy local/demo.
- Trước khi đưa lên Internet phải đổi mật khẩu Admin và bổ sung session/JWT, hash mật khẩu, kiểm tra file upload, CSRF/rate-limit và database thật.
- Nạp thẻ hiện là quy trình gửi yêu cầu + Admin duyệt, chưa tự động gọi API nhà cung cấp.
- Không dùng để xử lý thẻ thật khi chưa tích hợp cổng thanh toán hợp lệ.
